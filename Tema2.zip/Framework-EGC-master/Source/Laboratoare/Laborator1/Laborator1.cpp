#include "Laborator1.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

// Order of function calling can be seen in "Source/Core/World.cpp::LoopUpdate()"
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/World.cpp

Laborator1::Laborator1()
{
	
}

Laborator1::~Laborator1()
{
}

void Laborator1::Init()
{
	// Load a mesh from file into GPU memory
	{
		Mesh *mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;

		Mesh *sphere = new Mesh("sphere");
		sphere->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[sphere->GetMeshID()] = sphere;


		Mesh *quad = new Mesh("quad");
		quad->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "quad.obj");
		meshes[quad->GetMeshID()] = quad;

	}
}

void Laborator1::FrameStart()
{

}

void Laborator1::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->props.resolution;

	// sets the clear color for the color buffer
	
	if (!isColor)
	{
		glClearColor(0, 0, 0, 1);
	}
	else
	{
		/*glClearColor(1, 1, 0, 1);*/ //galben
		glClearColor(0, 1, 0, 1);
	}
		
	
	// clears the color buffer (using the previously set color) and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);

	// render the object
	RenderMesh(meshes["box"], glm::vec3(1, 0.5f, 0), glm::vec3(0.5f));
	RenderMesh(meshes["sphere"], glm::vec3(-0.7, 1.0f, -3.0), glm::vec3(1.0f));
	RenderMesh(meshes["quad"], glm::vec3(0.3, 0.3f, 0.1), glm::vec3(0.3f));

	// render the object again but with different properties
	RenderMesh(meshes["box"], glm::vec3(-1, 0.5f, 0));
	RenderMesh(meshes["sphere"], glm::vec3(x, y, z));

	chgObject();
	RenderMesh(meshes[objName], glm::vec3(0, 0, 0), objScale);



}

void Laborator1::FrameEnd()
{
	DrawCoordinatSystem();
}

// Read the documentation of the following functions in: "Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void Laborator1::OnInputUpdate(float deltaTime, int mods)
{
	// treat continuous update based on input
	if (canBeObjectMoved) {
		//cout << deltaTime << endl;
		if (window->KeyHold(GLFW_KEY_W))
			z -= deltaTime * 2;
		if (window->KeyHold(GLFW_KEY_A))
			x -= deltaTime * 2;
		if (window->KeyHold(GLFW_KEY_S))
			z += deltaTime * 2;
		if (window->KeyHold(GLFW_KEY_D))
			x += deltaTime * 2;
		if (window->KeyHold(GLFW_KEY_Q))
			y += deltaTime * 2;
		if (window->KeyHold(GLFW_KEY_E))
			y -= deltaTime * 2;
	}

};

void Laborator1::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_V) {
		if (isColor)
			isColor = false;
		else
			isColor = true;
	}
	
	if (key == GLFW_KEY_X)
	{
		objectCase = (objectCase + 1) % NUM_OBJECTS;
		chgObject();
	}

	if (key == GLFW_KEY_P) {
		if (canBeObjectMoved)
			canBeObjectMoved = false;
		else
			canBeObjectMoved = true;
	}



};

void Laborator1::OnKeyRelease(int key, int mods)
{
	// add key release event
};

void Laborator1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
};

void Laborator1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
};

void Laborator1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
	// treat mouse scroll event
}

void Laborator1::OnWindowResize(int width, int height)
{
	// treat window resize event
}

void Laborator1::chgObject()
{
	switch (objectCase)
	{
	case 1:
		objName = "sphere";
		objScale = glm::vec3(0.1f);
		break;

	case 2:
		objName = "quad";
		objScale = glm::vec3(0.2f);
		break;

	default:
		objName = "box";
		objScale = glm::vec3(0.3f);
		break;
	}
}