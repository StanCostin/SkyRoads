#pragma once
#include<ctime>
#include<Core/Engine.h>
#include<Component/SimpleScene.h>
#include"Objects2D.h"
#include"Transformer2D.h"
#include<iostream>
#include<vector>
#include<GLFW/glfw3.h>

using namespace std;

class BowAndArrow: public SimpleScene
{

public:

	BowAndArrow();
	~BowAndArrow();

private:

	void Init() override;

	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;
	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods);
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods);
	void movementShuriken(float x, float y, float speed, double a, float dts);
	void movementBallonsRed(float x, float y, float speed, float dts);
	void movementBallonsYellow(float x, float y, float speed, float dts);
	void movementBow(float x, float y);
	void movementArrow(float x, float y);
	void vColissonArrowBallon();
	void shurikenColisionPlayer();
	void renderPowerBar(int i);
	void createCamera();
	void createShapes();

	Mesh* bow;
	Mesh* stringBow;
	Mesh* arrowBody;
	Mesh* redBallonBody;
	Mesh* yellowBallonBody;
	Mesh* arrowHead;
	Mesh* baseYellowBallon;
	Mesh* baseRedBallon;
	Mesh* threadBallon;
	Mesh* shuriken1;
	Mesh* shuriken2;
	Mesh* shuriken3;
	Mesh* shuriken4;
	Mesh* hitBox;
	Mesh* powerBar;
	Mesh* sizePowerBar;

	glm::vec3 corner;

	glm::mat3 matModel;
	glm::mat3 matStringBow;
	glm::mat3 mats1;
	glm::mat3 mats2;
	glm::mat3 mats3;
	glm::mat3 mats4;
	glm::mat3 matHitBox;
	glm::mat3 matPowerBar;
	glm::mat3 matSizePowerBar;

	glm::mat3 matbr;
	glm::mat3 matBaseBallonr;
	glm::mat3 matThreadbr;
	glm::mat3 matby;
	glm::mat3 matBaseBallony;
	glm::mat3 matThreardby;

	float translateBowOx;
	float translateBowOy;

	float translateArrow;
	float translateArrowOx;
	float translateArrowOy;

	float bowRotation;
	float stringBowRotation;

	int score;
	int lives;
	int counter = 0;

	float saveShurikenSpeed;
	float saveShurikenY;

	float saveBowOx;
	float saveBowOy;

	float saveArrowOx;
	float saveArrowOy;

	float ballonX;
	float ballonX1;
	float ballonX2;
	float ballonX3;
	float ballonX4;
	float ballonX5;
	float ballonX6;
	float ballonX7;
	float ballonX8;
	float ballonX9;
	float ballonX10;

	float ballonY;
	float ballonY1;
	float ballonY2;
	float ballonY3;
	float ballonY4;
	float ballonY5;
	float ballonY6;
	float ballonY7;
	float ballonY8;
	float ballonY9;
	float ballonY10;

	float ballonXg;
	float ballonXg1;
	float ballonXg2;
	float ballonXg3;

	float ballonYg;
	float ballonYg1;
	float ballonYg2;
	float ballonYg3;

	float hitBoxSize;
	float cx;
	float cy;

	float cxaHitBoxg;
	float cxaHitBoxg1;
	float cxaHitBoxg2;
	float cxaHitBoxg3;
	float cxaHitBoxg4;
	float cxaHitBoxg5;
	float cxaHitBox;
	float cxaHitBox1;
	float cxaHitBox2;
	float cxaHitBox3;
	float cxaHitBox4;
	float cxaHitBox5;
	float cxaHitBox6;
	float cxaHitBox7;
	float cxaHitBox8;
	float cxaHitBox9;
	float cxaHitBox10;
	float cyaHitBox;

	float cxaShuriken;
	float cyaShuriken;

	bool isAllRight;
	bool isColission;
	bool isColission1;
	bool isColission2;
	bool isColission3;
	bool isColission4;
	bool isColission5;
	bool isColission6;
	bool isColission7;
	bool isColission8;
	bool isColission9;
	bool isColission10;
	bool isColissiony;
	bool isColissiony1;
	bool isColissiony2;
	bool isColissiony3;
	bool isHit;
	bool isEnd;
	bool isColissionShuriken;
	bool isPower;

	float radiusBow;
	float radiusBallon;

	float shurikenSpeed;

	float baseRedBOx;
	float baseRedBOy;

	float baseYellowBOx;
	float baseYellowBOy;

	float shurikenOx;
	float shurikenOy;
	float redBallonOx;
	float redBallonOy;
	float yellowBallonOx;
	float yellowBallonOy;


	float angleBow;
	float arrowAngle;
	float threadBallonAngle;
	float angleShuriken;
	float maintainSpeed;
	float maintainBallonSpeed;
	float msBallonYellow;

};