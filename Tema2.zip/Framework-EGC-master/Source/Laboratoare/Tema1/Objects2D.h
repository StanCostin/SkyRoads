#pragma once

#include <string>

#include <include/glm.h>
#include <Core/GPU/Mesh.h>



namespace Objects2D
{

	// Create square with given bottom left corner, length and color

	Mesh* CreateCircle(std::string name, glm::vec3 center, float radius, glm::vec3 color, bool fill);
	Mesh* CreateBallons(std::string name, glm::vec3 center, float radius, glm::vec3 color, bool fill);
	Mesh* CreatePowerBarSize(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill);

}

