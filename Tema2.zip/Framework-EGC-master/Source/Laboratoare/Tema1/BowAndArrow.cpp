#include "BowAndArrow.h"

BowAndArrow::BowAndArrow()
{

}

void BowAndArrow::Init()
{
	createCamera();
	corner = glm::vec3(0, 0, 0);

	isAllRight = false;
	isColission = false;
	isColission1 = false;
	isColission2 = false;
	isColission3 = false;
	isColission4 = false;
	isColission5 = false;
	isColission6 = false;
	isColission7 = false;
	isColission8 = false;
	isColission9 = false;
	isColission10 = false;
	isColissiony = false;
	isColissiony1 = false;
	isColissiony2 = false;
	isColissiony3 = false;
	isEnd = false;
	isColissionShuriken = false;

	ballonX = 0;
	ballonY = 0;

	ballonXg = 0;
	ballonYg = 0;

	cxaHitBox = 0;
	cyaHitBox = 0;

	score = 0;
	lives = 3;

	saveBowOx = 0;
	saveBowOy = 0;
	radiusBow = 100;
	radiusBallon = 50;
	arrowAngle = 90;
	translateBowOx = 10;
	translateBowOy = 110;
	translateArrowOx = 0;
	translateArrowOy = 0;


	bowRotation = 0;
	stringBowRotation = 0;
	angleBow = (float)-1.6;
	shurikenSpeed = 0;
	shurikenOx = 0;
	shurikenOy = 0;
	redBallonOx = 600;
	redBallonOy = 10;

	maintainSpeed = 0;
	maintainBallonSpeed = 0;
	msBallonYellow = 0;
	yellowBallonOx = 700;
	yellowBallonOy = 10;

	baseYellowBOx = 0;
	baseYellowBOy = 0;

	hitBoxSize = 97;
	cx = corner.x + hitBoxSize / 2;
	cy = corner.y + hitBoxSize / 2;

	createShapes();
	
}

void BowAndArrow::FrameStart()
{
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glm::ivec2 resolution = window->GetResolution();
	glViewport(0, 0, resolution.x, resolution.y);
}

void BowAndArrow::Update(float deltaTimeSeconds)
{
	movementBow(translateBowOx, translateBowOy);
	cout << "Score:" << score << " ";

	if (!isEnd)
	{
		cout << "Lives:" << lives << endl;
	}
	else {
		cout << "Lives out: " << lives << endl;
		cout << "GG!" << endl;
		World::Exit();
	}

	if (!isAllRight) {
		movementArrow(saveArrowOx, saveArrowOy);
		translateArrowOx = 0;
	}
	else
	{
		translateArrow += (10 * counter + 300) * deltaTimeSeconds;
		movementArrow(translateArrowOx, translateArrowOy);

	}

	glm::ivec2 resolution = window->GetResolution();


	if (score >= 9 || score >= 8)
	{
		movementBallonsRed(redBallonOx - 200, redBallonOy, 10, deltaTimeSeconds);
		movementBallonsRed(redBallonOx - 250, redBallonOy, 10, deltaTimeSeconds);
		movementShuriken(resolution.x - 1, shurikenOy, 20, M_PI, deltaTimeSeconds);
		movementBallonsRed(redBallonOx + 50, redBallonOy - 90, 20, deltaTimeSeconds);
	}

	if (score == 8 || score >= 7)
	{

		movementBallonsYellow(yellowBallonOx - 400, yellowBallonOy, 10, deltaTimeSeconds);
		movementBallonsRed(redBallonOx + 50, redBallonOy, 20, deltaTimeSeconds);
		movementShuriken(resolution.x - 1, shurikenOy, 30, M_PI, deltaTimeSeconds);
	}

	if (score >= 6 || score >= 5)
	{
		movementBallonsRed(redBallonOx + 75, redBallonOy, 20, deltaTimeSeconds);
		movementBallonsRed(redBallonOx - 100, redBallonOy, 10, deltaTimeSeconds);

	}

	if (score == 5 || score >= 3)
	{
		movementBallonsRed(redBallonOx + 25, redBallonOy, 20, deltaTimeSeconds);
		movementBallonsYellow(yellowBallonOx - 200, yellowBallonOy, 10, deltaTimeSeconds);
	}

	if (score >= 2 || score >= 1)
	{
		movementShuriken(resolution.x - 1, shurikenOy, 10, M_PI, deltaTimeSeconds);
		movementBallonsRed(redBallonOx - 350, redBallonOy, 10, deltaTimeSeconds);
		movementBallonsRed(redBallonOx - 300, redBallonOy, 10, deltaTimeSeconds);
		movementBallonsRed(redBallonOx - 150, redBallonOy, 10, deltaTimeSeconds);
		movementBallonsYellow(yellowBallonOx, yellowBallonOy, 10, deltaTimeSeconds);
	}


	movementBallonsRed(redBallonOx + 85, redBallonOy, 10, deltaTimeSeconds);
	movementBallonsYellow(yellowBallonOx - 90, yellowBallonOy, 10, deltaTimeSeconds);
	movementBallonsRed(redBallonOx, redBallonOy, 20, deltaTimeSeconds);


	if ((isColissiony == true) && (isColissiony1 == true) && (isColissiony2 == true) && (isColissiony3 == true))
	{
		cout << "Ai lovit toate baloanele galbene" << endl;
		World::Exit();
	}

	if (score == 11)
	{
		cout << "Ai lovit toate baloanele rosii" << endl;
		World::Exit();
	}

	vColissonArrowBallon();
	shurikenColisionPlayer();

	for (int i = 0; i <= counter; i++)
	{
		renderPowerBar(i);
	}
}

void BowAndArrow::FrameEnd()
{

}

void BowAndArrow::OnInputUpdate(float deltaTime, int mods)
{
	if (window->KeyHold(GLFW_KEY_W))
	{
		translateBowOy += 120 * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_S))
	{
		translateBowOy -= 120 * deltaTime;
	}

	if (window->MouseHold(GLFW_MOUSE_BUTTON_LEFT))
	{
		if (isPower)
			isPower = true;


		if (counter < 100)
			counter++;

	}
}

void BowAndArrow::OnKeyPress(int key, int mods)
{

}

void BowAndArrow::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	if (!button == GLFW_MOUSE_BUTTON_LEFT && button == GLFW_MOUSE_BUTTON_RIGHT && isAllRight == false)
	{
		counter = 0;
	}

};

void BowAndArrow::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	if (!button == GLFW_MOUSE_BUTTON_LEFT && button == GLFW_MOUSE_BUTTON_RIGHT && isAllRight == false)
	{
		translateArrowOx = saveArrowOx;
		translateArrowOy = saveArrowOy;
		isAllRight = true;
		isPower = false;
	}
}

void BowAndArrow::movementShuriken(float x, float y, float speed, double angle, float dts)
{
	mats1 = Transformer2D::Translate(x, y)  * Transformer2D::Scale(20, 20);
	mats2 = Transformer2D::Translate(x, y)  * Transformer2D::Scale(20, 20);
	mats3 = Transformer2D::Translate(x, y)  * Transformer2D::Scale(20, 20);
	mats4 = Transformer2D::Translate(x, y)  * Transformer2D::Scale(20, 20);

	maintainSpeed -= speed * dts;
	shurikenSpeed += angle * dts;
	saveShurikenSpeed = maintainSpeed;
	saveShurikenY = y;


	if (x + maintainSpeed >= 1216) {

		if (!isColissionShuriken) {
			mats1 *= Transformer2D::Translate(maintainSpeed, 20) * Transformer2D::Rotate(shurikenSpeed);
			mats2 *= Transformer2D::Translate(maintainSpeed, 20) * Transformer2D::Rotate(shurikenSpeed);
			mats3 *= Transformer2D::Translate(maintainSpeed, 20) * Transformer2D::Rotate(shurikenSpeed);
			mats4 *= Transformer2D::Translate(maintainSpeed, 20) * Transformer2D::Rotate(shurikenSpeed);

			RenderMesh2D(meshes["shuriken1"], shaders["VertexColor"], mats1);
			RenderMesh2D(meshes["shuriken2"], shaders["VertexColor"], mats2);
			RenderMesh2D(meshes["shuriken3"], shaders["VertexColor"], mats3);
			RenderMesh2D(meshes["shuriken4"], shaders["VertexColor"], mats4);
		}
		else {
			isColissionShuriken = false;
		}

	}
	else
	{
		maintainSpeed = 0;
	}
}

void BowAndArrow::movementBallonsRed(float x, float y, float speed, float dts)
{
	if (y - maintainBallonSpeed <= 660) {

		if (!isColission && (x == redBallonOx))
		{
			ballonX = x;
			ballonY = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission1 && (x == redBallonOx - 200))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX1 = x;
			ballonY1 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 129.5, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 118, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission2 && (x == redBallonOx - 100))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX2 = x;
			ballonY2 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 158, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 145, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission3 && (x == redBallonOx - 150))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX3 = x;
			ballonY3 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 145, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 130, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission4 && (x == redBallonOx - 250))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX4 = x;
			ballonY4 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 114.5, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 100, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission5 && (x == redBallonOx - 300))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX5 = x;
			ballonY5 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 100, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 85, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission6 && (x == redBallonOx - 350))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX6 = x;
			ballonY6 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 85, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 70, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission7 && (x == redBallonOx + 50))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX7 = x;
			ballonY7 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 204.5, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 190, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission8 && (x == redBallonOx + 25))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX8 = x;
			ballonY8 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 196, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 182, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission9 && (x == redBallonOx + 75))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX9 = x;
			ballonY9 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 213, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 200, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}


		if (!isColission10 && (x == redBallonOx + 85))
		{
			maintainBallonSpeed -= speed * dts;
			ballonX10 = x;
			ballonY10 = y - maintainBallonSpeed;
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 215, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 200, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matbr = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matbr *= Transformer2D::Translate(x, y - maintainBallonSpeed);
			maintainBallonSpeed -= speed * dts;
			RenderMesh2D(meshes["redBallonBody"], shaders["VertexColor"], matbr);

			matBaseBallonr = Transformer2D::Translate(x - 189, y - 55);
			matBaseBallonr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseRedBallon"], shaders["VertexColor"], matBaseBallonr);

			matThreadbr = Transformer2D::Translate(x - 175, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - maintainBallonSpeed) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}

	}
	else
	{
		maintainBallonSpeed = 0;
	}
}

void BowAndArrow::movementBallonsYellow(float x, float y, float speed, float dts)
{
	if (y - msBallonYellow <= 660) {

		if (!isColissiony && (x == yellowBallonOx)) {
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;

			ballonXg = x;
			ballonYg = y - msBallonYellow;
			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);

			matBaseBallony = Transformer2D::Translate(x - 219, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 205, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{

			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;

			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);
			matBaseBallony = Transformer2D::Translate(x - 219, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 205, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}

		if (!isColissiony1 && (x == yellowBallonOx - 200)) {
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;
			ballonXg1 = x;
			ballonYg1 = y - msBallonYellow;
			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);

			matBaseBallony = Transformer2D::Translate(x - 160, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 150, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;
			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);

			matBaseBallony = Transformer2D::Translate(x - 219, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);

			matThreadbr = Transformer2D::Translate(x - 205, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		if (!isColissiony2 && (x == yellowBallonOx - 400)) {
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;

			ballonXg2 = x;
			ballonYg2 = y - msBallonYellow;

			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);
			matBaseBallony = Transformer2D::Translate(x - 100, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 85, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;


			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);
			matBaseBallony = Transformer2D::Translate(x - 219, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 205, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}

		if (!isColissiony3 && (x == yellowBallonOx - 90)) {
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0.7, 1.0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;

			ballonXg3 = x;
			ballonYg3 = y - msBallonYellow;

			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);
			matBaseBallony = Transformer2D::Translate(x - 195, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 180, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(10, 10) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}
		else
		{
			matby = Transformer2D::Translate(x, y) * Transformer2D::Scale(0, 0);
			matby *= Transformer2D::Translate(x, y - msBallonYellow);
			msBallonYellow -= speed * dts;
			RenderMesh2D(meshes["yellowBallonBody"], shaders["VertexColor"], matby);

			matBaseBallony = Transformer2D::Translate(x - 219, y - 55);
			matBaseBallony *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0);
			RenderMesh2D(meshes["baseYellowBallon"], shaders["VertexColor"], matBaseBallony);


			matThreadbr = Transformer2D::Translate(x - 205, y - 80);
			matThreadbr *= Transformer2D::Translate(x, y - msBallonYellow) * Transformer2D::Scale(0, 0) * Transformer2D::Rotate(M_PI / 2);
			RenderMesh2D(meshes["threadBallon"], shaders["VertexColor"], matThreadbr);
		}

	}
	else
	{
		msBallonYellow = 0;
	}
}

void BowAndArrow::movementBow(float x, float y)
{
	if (y > 619)
		y = 619;
	else if (y < 167)
		y = 167;
	matModel = glm::mat3(1);
	matModel = Transformer2D::Translate(x, y);
	matModel *= Transformer2D::Rotate(angleBow);
	RenderMesh2D(meshes["bow"], shaders["VertexColor"], matModel);

	saveBowOx = x;
	saveBowOy = y;

	matStringBow = Transformer2D::Translate(x, y - 100) * Transformer2D::Scale(100, 200);
	RenderMesh2D(meshes["stringBow"], shaders["VertexColor"], matStringBow);

	saveArrowOx = x;
	saveArrowOy = y;

}

void BowAndArrow::movementArrow(float x, float y)
{

	if (translateArrow + 125 + x <= 1250) {

		matModel = Transformer2D::Translate(translateArrow + x, y) * Transformer2D::Scale(2.5, 2.5);
		RenderMesh2D(meshes["arrowBody"], shaders["VertexColor"], matModel);

		cxaHitBox = translateArrow - 440 + x;
		cxaHitBox1 = translateArrow - 200 + x;
		cxaHitBox2 = translateArrow - 205 + x;
		cxaHitBox3 = translateArrow - 210 + x;
		cxaHitBox4 = translateArrow - 130 + x;
		cxaHitBox5 = translateArrow - 100 + x;
		cxaHitBox6 = translateArrow - 50 + x;
		cxaHitBox7 = translateArrow - 350 + x;
		cxaHitBox8 = translateArrow - 350 + x;
		cxaHitBox9 = translateArrow - 370 + x;
		cxaHitBox10 = translateArrow - 380 + x;

		cxaHitBoxg = translateArrow - 560 + x;
		cxaHitBoxg1 = translateArrow - 400 + x;
		cxaHitBoxg2 = translateArrow - 195 + x;
		cxaHitBoxg3 = translateArrow - 500 + x;
		cyaHitBox = y - 6;

		
		cxaShuriken = translateArrow - 500 + x;
		cyaShuriken = y - 6;

		matModel = Transformer2D::Translate(translateArrow + 125 + x, y - 6) * Transformer2D::Scale(20, 20);
		RenderMesh2D(meshes["arrowHead"], shaders["VertexColor"], matModel);
	}
	else
	{
		translateArrow = 0;
		isAllRight = false;
	}
}

void BowAndArrow::vColissonArrowBallon()
{
	if (isColission == false) {
		if (cxaHitBox > (ballonX - 150) && (cyaHitBox < ballonY + 50) && (cyaHitBox > ballonY - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission = true;
			score++;
		}
	}


	if (isColission1 == false)
	{
		if (cxaHitBox1 > (ballonX1 - 50) && (cyaHitBox < ballonY1 + 50) && (cyaHitBox > ballonY1 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission1 = true;
			score++;
		}
	}

	if (isColission2 == false) {
		if (cxaHitBox2 > (ballonX2 - 50) && (cyaHitBox < ballonY2 + 50) && (cyaHitBox > ballonY2 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission2 = true;
			score++;
		}
	}

	if (isColission3 == false) {

		if (cxaHitBox3 > (ballonX3 - 50) && (cyaHitBox < ballonY3 + 50) && (cyaHitBox > ballonY3 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission3 = true;
			score++;
		}

	}

	if (isColission4 == false) {
		if (cxaHitBox4 > (ballonX4 - 50) && (cyaHitBox < ballonY4 + 50) && (cyaHitBox > ballonY4 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission4 = true;
			score++;
		}
	}

	if (isColission5 == false) {
		if (cxaHitBox5 > (ballonX5 - 50) && (cyaHitBox < ballonY5 + 50) && (cyaHitBox > ballonY5 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission5 = true;
			score++;
		}
	}

	if (isColission6 == false) {
		if (cxaHitBox6 > (ballonX6 - 50) && (cyaHitBox < ballonY6 + 50) && (cyaHitBox > ballonY6 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission6 = true;
			score++;
		}
	}

	if (isColission7 == false) {
		if (cxaHitBox7 > (ballonX7 - 50) && (cyaHitBox < ballonY7 + 50) && (cyaHitBox > ballonY7 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission7 = true;
			score++;
		}
	}

	if (isColission8 == false) {
		if (cxaHitBox8 > (ballonX8 - 50) && (cyaHitBox < ballonY8 + 50) && (cyaHitBox > ballonY8 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission8 = true;
			score++;
		}
	}

	if (isColission9 == false) {
		if (cxaHitBox9 > (ballonX9 - 50) && (cyaHitBox < ballonY9 + 50) && (cyaHitBox > ballonY9 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission9 = true;
			score++;
		}
	}

	if (isColission10 == false) {
		if (cxaHitBox10 > (ballonX10 - 50) && (cyaHitBox < ballonY10 + 50) && (cyaHitBox > ballonY10 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColission10 = true;
			score++;
		}
	}

	if (isColissiony == false) {

		if (cxaHitBoxg > (ballonXg - 200) && (cyaHitBox < ballonYg + 50) && (cyaHitBox > ballonYg - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColissiony = true;
			score--;
		}

	}

	if (isColissiony1 == false) {

		if (cxaHitBoxg1 > (ballonXg1 - 200) && (cyaHitBox < ballonYg1 + 50) && (cyaHitBox > ballonYg1 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColissiony1 = true;
			score--;
		}

	}

	if (isColissiony2 == false) {

		if (cxaHitBoxg2 > (ballonXg2 - 100) && (cyaHitBox < ballonYg2 + 60) && (cyaHitBox > ballonYg2 - 60))
		{
			translateArrow = 0;
			isAllRight = false;
			isColissiony2 = true;
			score--;
		}
	}

	if (isColissiony3 == false) {

		if (cxaHitBoxg3 > (ballonXg3 - 200) && (cyaHitBox < ballonYg3 + 50) && (cyaHitBox > ballonYg3 - 50))
		{
			translateArrow = 0;
			isAllRight = false;
			isColissiony3 = true;
			score--;
		}
	}

}

void BowAndArrow::shurikenColisionPlayer()
{
	if (isEnd == false)
	{
		if (isColissionShuriken == false) {

			if (-saveShurikenSpeed - 40 > saveBowOx && (saveBowOy - 300 < -saveShurikenY + 225) && (saveBowOy - 300 > -saveShurikenY - 20)) {
				isColissionShuriken = true;
				maintainSpeed = 0;
				lives--;
			}
		}
		if (lives == 0)
		{
			isEnd = true;
		}
	}
}

void BowAndArrow::renderPowerBar(int i)
{
	matSizePowerBar = Transformer2D::Translate(311, 60);
	matSizePowerBar *= Transformer2D::Scale(100, 17);
	matPowerBar = Transformer2D::Translate(10 + i, 10);
	matPowerBar *= Transformer2D::Scale(i, 50);
	RenderMesh2D(meshes["sizePowerBar"], shaders["VertexColor"], matSizePowerBar);
	RenderMesh2D(meshes["powerBar"], shaders["VertexColor"], matPowerBar);
}

void BowAndArrow::createCamera()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 45));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);
}

void BowAndArrow::createShapes()
{

	bow = Objects2D::CreateCircle("bow", corner, radiusBow, glm::vec3(1, 1, 1), false);
	AddMeshToList(bow);

	stringBow = new Mesh("stringBow");

	{
		vector<VertexFormat> veritcies
		{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(0,1,0),glm::vec3(1, 1, 1))
		};

		vector<unsigned short> indicies
		{
			0, 1
		};
		stringBow->SetDrawMode(GL_LINE_STRIP);
		stringBow->InitFromData(veritcies, indicies);
		AddMeshToList(stringBow);
	}

	arrowBody = new Mesh("arrowBody");
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(0,0,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(0,2,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(50,0,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(50,2,0), glm::vec3(1, 1, 1)),
		};

		vector<unsigned short> indices =
		{
			0, 1, 2,
			2, 3, 1
		};

		arrowBody->SetDrawMode(GL_TRIANGLES);
		arrowBody->InitFromData(vertices, indices);
		AddMeshToList(arrowBody);
	}

	arrowHead = new Mesh("arrowHead");
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(0,0,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(0,1,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(1,0.5,0), glm::vec3(1, 1, 1))

		};

		vector<unsigned short> indices
		{
			0, 1 , 2
		};

		arrowHead->SetDrawMode(GL_TRIANGLES);
		arrowHead->InitFromData(vertices, indices);
		AddMeshToList(arrowHead);
	}

	yellowBallonBody = Objects2D::CreateBallons("yellowBallonBody", corner, radiusBallon, glm::vec3(1, 1, 0), false);
	AddMeshToList(yellowBallonBody);

	baseYellowBallon = new Mesh("baseYellowBallon");
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(0,0,0), glm::vec3(1, 1, 0)),
			VertexFormat(glm::vec3(1,1,0), glm::vec3(1, 1, 0)),
			VertexFormat(glm::vec3(2,0,0), glm::vec3(1, 1, 0))

		};

		vector<unsigned short> indices
		{
			0, 1 , 2
		};

		baseYellowBallon->SetDrawMode(GL_TRIANGLES);
		baseYellowBallon->InitFromData(vertices, indices);
		AddMeshToList(baseYellowBallon);
	}

	redBallonBody = Objects2D::CreateBallons("redBallonBody", corner, radiusBallon, glm::vec3(1, 0, 0), false);
	AddMeshToList(redBallonBody);

	baseRedBallon = new Mesh("baseRedBallon");
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(0,0,0), glm::vec3(1, 0, 0)),
			VertexFormat(glm::vec3(1,1,0), glm::vec3(1, 0, 0)),
			VertexFormat(glm::vec3(2,0,0), glm::vec3(1, 0, 0))
		};

		vector<unsigned short> indices
		{
			0, 1 , 2
		};

		baseRedBallon->SetDrawMode(GL_TRIANGLES);
		baseRedBallon->InitFromData(vertices, indices);
		AddMeshToList(baseRedBallon);
	}

	threadBallon = new Mesh("threadBallon");
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(0,0,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(1,1,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(2,0,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(2,1,0), glm::vec3(1, 1, 1)),
			VertexFormat(glm::vec3(3,0,0), glm::vec3(1, 1, 1))

		};

		vector<unsigned short> indices
		{
			0, 1 , 2,
			2, 3 , 4

		};

		threadBallon->SetDrawMode(GL_LINE_STRIP);
		threadBallon->InitFromData(vertices, indices);
		AddMeshToList(threadBallon);
	}

	shuriken1 = new Mesh("shuriken1");
	{
		vector<VertexFormat> verticies
		{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(1,0,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(1,1,0),glm::vec3(1,1,1))
		};

		vector<unsigned short> indices
		{
			0, 1, 2
		};


		shuriken1->SetDrawMode(GL_TRIANGLES);
		shuriken1->InitFromData(verticies, indices);
		AddMeshToList(shuriken1);

	}
	shuriken2 = new Mesh("shuriken2");
	{
		vector<VertexFormat> verticies
		{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(0,1,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(-1,1,0),glm::vec3(1,1,1))
		};

		vector<unsigned short> indices
		{
			0, 1, 2
		};


		shuriken2->SetDrawMode(GL_TRIANGLES);
		shuriken2->InitFromData(verticies, indices);
		AddMeshToList(shuriken2);

	}
	shuriken3 = new Mesh("shuriken3");
	{
		vector<VertexFormat> verticies
		{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(-1,0,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(-1,-1,0),glm::vec3(1,1,1))
		};

		vector<unsigned short> indices
		{
			0, 1, 2
		};
		shuriken3->SetDrawMode(GL_TRIANGLES);
		shuriken3->InitFromData(verticies, indices);
		AddMeshToList(shuriken3);
	}
	shuriken4 = new Mesh("shuriken4");
	{
		vector<VertexFormat> verticies
		{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(0,-1,0),glm::vec3(1,1,1)),
			VertexFormat(glm::vec3(1,-1,0),glm::vec3(1,1,1))
		};

		vector<unsigned short> indices
		{
			0, 1, 2
		};
		shuriken4->SetDrawMode(GL_TRIANGLES);
		shuriken4->InitFromData(verticies, indices);
		AddMeshToList(shuriken4);
	}

	powerBar = new Mesh("powerBar");

	{
		vector<VertexFormat> verticies{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(0,1,0)), //0
			VertexFormat(glm::vec3(2,0,0),glm::vec3(0,1,0)), //1
			VertexFormat(glm::vec3(0,1,0),glm::vec3(0,1,0)), //2
			VertexFormat(glm::vec3(2,1,0),glm::vec3(0,1,0))  //3
		};

		vector<unsigned short> indicies{
			0, 1, 2,
			2, 3, 1
		};
		powerBar->SetDrawMode(GL_TRIANGLE_FAN);
		powerBar->InitFromData(verticies, indicies);
		AddMeshToList(powerBar);
	}

	sizePowerBar = Objects2D::CreatePowerBarSize("sizePowerBar", corner, hitBoxSize - 100, glm::vec3(0, 1, 0), false);
	AddMeshToList(sizePowerBar);
}

BowAndArrow::~BowAndArrow()
{
	delete arrowBody;
	delete arrowHead;
	delete bow;
	delete stringBow;
	delete redBallonBody;
	delete yellowBallonBody;
	delete baseYellowBallon;
	delete baseRedBallon;
	delete threadBallon;
	delete shuriken1;
	delete shuriken2;
	delete shuriken3;
	delete shuriken4;
	delete powerBar;
	delete sizePowerBar;
}