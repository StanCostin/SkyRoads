#pragma once

typedef struct Cube {
	float x;
	float y;
	float z;
}structCube;