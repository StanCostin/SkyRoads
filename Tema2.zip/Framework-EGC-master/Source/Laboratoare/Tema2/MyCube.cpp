#include"MyCube.h"

MyCube::MyCube()
{
	xc = 0;
	yc = 0;
	zc = 0;
	tc = 0;
}

MyCube::MyCube(int s) : size(s)
{
}

MyCube::MyCube(float x, float y, float z, float t) : xc(x), yc(y), zc(z), tc(t)
{
}

void MyCube::setXcoordinate(float x)
{
	xc = x;
}

void MyCube::setYcoordinate(float y)
{
	yc = y;
}

void MyCube::setZcoordinate(float z)
{
	zc = z;
}

void MyCube::setTcoordinate(float t)
{
	tc = t;
}

float MyCube::getXcoordinate()
{
	return xc;
}

float MyCube::getYcoordinate()
{
	return yc;
}

float MyCube::getZcoordinate()
{
	return zc;
}

float MyCube::getTcoordinate()
{
	return tc;
}

MyCube::~MyCube()
{

}